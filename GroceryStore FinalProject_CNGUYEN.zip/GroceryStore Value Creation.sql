USE GroceryStoreDb;
GO

INSERT INTO Customers (First_Name, Last_Name, ADDRESS, Email_Address, Loyalty_Member)
VALUES 
('Clark', 'Kent', '123 Metropolis Drive', 'CKentSups@dailyplanet.com', 'Yes'),
('Bruce', 'Wayne', '456 Gotham Way', 'BWayneBats@gothgazette.com', 'Yes'),
('Dick', 'Grayson', '789 Gotham Avenue NE', 'BlueBird@teentitans.com', 'Yes'),
('Jason', 'Todd', '112 Gotham Ave Court E', 'RedHood@theoutlaws.com', 'No'),
('Lois', 'Lane', '1314 Metropolis Way', 'LLane@dailyplanet.com', 'No'),
('Jimmy', 'Olsen', '1516 Metropolis Lane', 'LadiesMan@dailyplanet.com', 'Yes'),
('Lex', 'Luthor', '1718 Metropolis Drive NE', 'CertifiedSoupHater@luthorcorp.com', 'No'),
('Miku', 'Hatsune', '1819 Crypton Future Way SW', 'LeekLoverCV01@vocaloid.com', 'Yes'),
('Katsuki', 'Bakugo', '201 Academia Avenue E', 'Dynamight@allmight.com', 'Yes'),
('Kento', 'Nanami', '223 Bakers Lane SE', 'Ihateovertime@jujutsu.com', 'Yes');

INSERT INTO Categories (CategoryName, StorageCondition)
VALUES 
('Common_Fruit', 'Dry'),
('Topical_Fruit', 'Chilled'),
('Fresh_Vegetable', 'Misted'),
('Leafy_Greens', 'Misted');

INSERT INTO Products (Product_Name, Price, Category, Quantity, CategoryID, Unit_Type)
VALUES
('Apples', '3.00', 'Fruit', '1000', 1,'LBS'),
('Oranges', '4.00', 'Fruit', '2000', 1, 'LBS'),
('Watermelon', '10.00', 'Fruit', '500', 2, 'LBS'),
('Mango', '3.00', 'Fruit', '750', 2, 'EA'),
('Avocado', '5.00', 'Fruit', '600', 2, 'EA'),
('Broccoli', '2.00', 'Vegetable', '900', 3, 'LBS'),
('Lettuce', '3.50', 'Vegetable', '1000', 4, 'BUNCH'),
('Bokchoy', '3.00', 'Vegetable', '500', 3, 'BUNCH'),
('Carrots', '2.00', 'Vegetable', '900', 3, 'LBS'),
('Spinach', '3.00', 'Vegetable', '800', 4, 'BUNCH');

INSERT INTO Orders (CustomerID, Order_Type, Total_Amount, PaymentMethod, DeliveryAddress)
VALUES
(1, 'Online', 10.00, 'CREDIT', '123 Metropolis Drive'),
(2, 'InStore', 20.00, 'CASH', NULL),
(3, 'InStore', 15.00, 'CREDIT', NULL),
(4, 'InStore', 25.00, 'CASH', NULL),
(5, 'InStore', 30.00, 'CREDIT', NULL),
(6, 'Online', 20.00, 'CREDIT', '1516 Metropolis Lane'),
(7, 'Online', 35.00, 'CREDIT', '1718 Metropolis Drive NE'),
(8, 'InStore', 10.00, 'CASH', NULL),
(9, 'InStore', 20.00, 'CREDIT', NULL),
(10, 'InStore', 15.00, 'CASH', NULL);

INSERT INTO OrderDetails (OrderID, ProductID, Quantity, UnitPrice)
VALUES
(1, 1, 2.00, 3.00), 
(1, 4, 1.00, 4.00), 
(2, 2, 5.00, 4.00),
(3, 3, 1.00, 10.00),
(3, 5, 1.00, 5.00),
(4, 5, 5.00, 5.00),
(5, 9, 15.00, 2.00),
(6, 6, 10.00, 2.00),
(7, 10, 10.00, 3.00),
(7, 9, 2.50, 2.00),
(8, 8, 5.00, 2.00),
(9, 7, 5.00, 3.50),
(9, 6, 1.25, 2.00),
(10, 10, 5.00, 3.00);
