
--Customer purchase:
DECLARE @PickedProductID INT = 1;     
DECLARE @DesiredQuantity INT = 5;     
DECLARE @CurrentCustomerID INT = 1;   

BEGIN TRANSACTION;

BEGIN TRY

    DECLARE @AvailableStock INT;
    
    SELECT @AvailableStock = Quantity 
    FROM Products 
    WHERE ProductID = @PickedProductID;

    IF @AvailableStock >= @DesiredQuantity
    BEGIN
       
        INSERT INTO Orders (CustomerID, Order_Type, Total_Amount, PaymentMethod)
        VALUES (@CurrentCustomerID, 'Online', 15.00, 'CREDIT');
        DECLARE @NewOrderID INT = SCOPE_IDENTITY();
        INSERT INTO OrderDetails (OrderID, ProductID, Quantity, UnitPrice)
        VALUES (@NewOrderID, @PickedProductID, @DesiredQuantity, 3.00);

  
        UPDATE Products
        SET Quantity = Quantity - @DesiredQuantity
        WHERE ProductID = @PickedProductID;

       
        COMMIT TRANSACTION;
        PRINT 'Purchase Successful! Stock updated and order recorded.';
    END
    ELSE
    BEGIN
        
        ROLLBACK TRANSACTION;
        PRINT 'Purchase Cancelled: Not enough items available in the store.';
    END
END TRY
BEGIN CATCH
    
    IF @@TRANCOUNT > 0
    BEGIN
        ROLLBACK TRANSACTION;
    END
    
    PRINT 'An unexpected database error occurred. Transaction rolled back.';
    PRINT ERROR_MESSAGE();
END CATCH;