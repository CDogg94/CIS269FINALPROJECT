USE GroceryStoreDB;
GO

CREATE TABLE Customers (
	CustomerID INT IDENTITY (1, 1) PRIMARY KEY, 
	First_Name VARCHAR(60) NOT NULL,
	Last_Name VARCHAR(60) NOT NULL, 
	ADDRESS VARCHAR(100) NOT NULL,
	Email_Address VARCHAR(100) UNIQUE NOT NULL,
	Loyalty_Member VARCHAR(60) NOT NULL
	);

CREATE TABLE Categories (
	CategoryID INT IDENTITY (1, 1) PRIMARY KEY, 
	CategoryName VARCHAR(60) NOT NULL UNIQUE, 
	StorageCondition VARCHAR(40) NOT NULL CHECK (StorageCondition IN ('Chilled', 'Dry', 'Misted'))
	);

CREATE TABLE Products (
	ProductID INT IDENTITY (1, 1) PRIMARY KEY, 
	Product_Name VARCHAR(100) NOT NULL, 
	Price DECIMAL(10, 2) CHECK (price >= 0),
	Category VARCHAR(60) NOT NULL, 
	Quantity INT NOT NULL CHECK (Quantity >= 0),
	CategoryID INT NOT NULL, 
	Unit_Type VARCHAR(10) NOT NULL CHECK (Unit_Type IN ('LBS', 'EA', 'BUNCH')),
	FOREIGN KEY (CategoryID) REFERENCES Categories(CategoryID)
);

CREATE TABLE Orders (
	OrderID INT IDENTITY (1, 1) PRIMARY KEY, 
	CustomerID INT NOT NULL,
	Order_Date DATE DEFAULT CAST(CURRENT_TIMESTAMP AS DATE),
	Order_Type VARCHAR(10) NOT NULL,
	Total_Amount DECIMAL(10, 2) NOT NULL,
	PaymentMethod VARCHAR(20) NOT NULL CHECK (PaymentMethod IN ('CASH', 'CREDIT')),
	DeliveryAddress VARCHAR(255) NULL,
	FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
	);

CREATE TABLE OrderDetails (
	OrderDetails_ID INT IDENTITY(1, 1) PRIMARY KEY,
    OrderID INT NOT NULL,
    ProductID INT NOT NULL,
    Quantity DECIMAL(6, 2) NOT NULL,
    UnitPrice DECIMAL(10, 2) NOT NULL, 
    Transaction_Total AS CAST((Quantity * UnitPrice) AS DECIMAL(10, 2)), 
	FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);

