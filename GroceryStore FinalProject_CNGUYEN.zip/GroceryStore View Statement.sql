CREATE VIEW CustomerReceipts AS
SELECT 
    c.CustomerID,
    CONCAT(c.First_Name, ' ', c.Last_Name) AS Customer_Name,
    o.OrderID,
    o.Order_Type,
    o.PaymentMethod,
    COUNT(od.ProductID) AS Unique_Items_Count,
    SUM(od.Quantity) AS Total_Physical_Units,
    CAST(SUM(od.Quantity * od.UnitPrice) AS DECIMAL(10, 2)) AS Calculated_Receipt_Total
FROM 
    Customers c
JOIN 
    Orders o ON c.CustomerID = o.CustomerID
JOIN 
    OrderDetails od ON o.OrderID = od.OrderID
GROUP BY 
    c.CustomerID,
    c.First_Name,
    c.Last_Name,
    c.Email_Address,
    c.Loyalty_Member,
    o.OrderID,
    o.Order_Type,
    o.PaymentMethod;

    SELECT * FROM CustomerReceipts;