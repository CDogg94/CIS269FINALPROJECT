GO 

CREATE TRIGGER CapitalizeLastName
ON Customers
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF UPDATE(Last_Name)
    BEGIN
        UPDATE c
        SET c.Last_Name = UPPER(i.Last_Name)
        FROM Customers c
        JOIN inserted i ON c.CustomerID = i.CustomerID;
    END
END;

GO 

INSERT INTO Customers (First_Name, Last_Name, ADDRESS, Email_Address, Loyalty_Member)
VALUES ('Damian', 'wayne', '456 Gotham Way', 'Robin05@gothgazette.com', 'Yes');

INSERT INTO Customers (First_Name, Last_Name, ADDRESS, Email_Address, Loyalty_Member)
VALUES ('Barbara', 'Gordon', '', 'GirlyBat@gothgazette.com', 'No');

SELECT * FROM Customers;