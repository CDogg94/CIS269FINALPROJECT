GO 

CREATE PROCEDURE GetCustomerReceiptsBySpending
    @CustID INT,                    
    @MinSpent DECIMAL(10, 2)        
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        CustomerID,
        Customer_Name,
        OrderID,
        Order_Type,
        PaymentMethod,
        Calculated_Receipt_Total
    FROM 
        CustomerReceipts 
    WHERE 
        CustomerID = @CustID 
        AND Calculated_Receipt_Total >= @MinSpent;
END;

GO 

EXEC GetCustomerReceiptsBySpending @CustID = 1, @MinSpent = 4.00;